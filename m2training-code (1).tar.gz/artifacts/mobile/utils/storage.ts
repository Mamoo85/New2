import AsyncStorage from "@react-native-async-storage/async-storage";

const KEY = "mmt_mobile_v1";

export interface Entry {
  lift: string;
  weight: number;
  sets?: number | null;
  reps?: number | null;
  date: string;
  note?: string;
}

export interface Message {
  id: string;
  type: string;
  text: string;
  preferredDate?: string | null;
  timestamp: string;
  trainerRead: boolean;
  dismissed: boolean;
  trainerReply: string | null;
}

export interface ChallengeLog {
  challengeId: string;
  amount: number;
  note?: string;
  date: string;
  timestamp: string;
}

export type DeliveryFrequency = "weekly" | "biweekly" | "monthly" | "bimonthly";

export const FREQ_LABELS: Record<DeliveryFrequency, string> = {
  weekly: "Weekly",
  biweekly: "Bi-Weekly",
  monthly: "Monthly",
  bimonthly: "Bi-Monthly",
};

export interface SubscriptionInfo {
  status: "active" | "paused" | "cancelled";
  startedAt: string;
  packageName: string;
  workoutFrequency: DeliveryFrequency | null;
  checkinFrequency: DeliveryFrequency | null;
  monthlyPrice: number;
  notes?: string;
}

export interface SubscriptionTemplate {
  name: string;
  packageName: string;
  includeWorkouts: boolean;
  workoutFrequency: DeliveryFrequency;
  includeCheckins: boolean;
  checkinFrequency: DeliveryFrequency;
  monthlyPrice: number;
  tagline: string;
  group: "Online Programs" | "In-Person Check-Ins" | "Combined";
}

export const SUBSCRIPTION_TEMPLATES: SubscriptionTemplate[] = [
  // Online Programs
  {
    name: "Online — Weekly",
    packageName: "Weekly Online Coaching",
    includeWorkouts: true,
    workoutFrequency: "weekly",
    includeCheckins: false,
    checkinFrequency: "monthly",
    monthlyPrice: 150,
    tagline: "New program every week",
    group: "Online Programs",
  },
  {
    name: "Online — Bi-Weekly",
    packageName: "Bi-Weekly Online Coaching",
    includeWorkouts: true,
    workoutFrequency: "biweekly",
    includeCheckins: false,
    checkinFrequency: "monthly",
    monthlyPrice: 125,
    tagline: "Fresh program every 2 weeks",
    group: "Online Programs",
  },
  {
    name: "Online — Monthly",
    packageName: "Monthly Online Coaching",
    includeWorkouts: true,
    workoutFrequency: "monthly",
    includeCheckins: false,
    checkinFrequency: "monthly",
    monthlyPrice: 100,
    tagline: "Monthly program block",
    group: "Online Programs",
  },
  {
    name: "Online — Bi-Monthly",
    packageName: "Bi-Monthly Online Coaching",
    includeWorkouts: true,
    workoutFrequency: "bimonthly",
    includeCheckins: false,
    checkinFrequency: "monthly",
    monthlyPrice: 75,
    tagline: "Program every 2 months",
    group: "Online Programs",
  },
  // In-Person Check-Ins
  {
    name: "In-Person — Weekly",
    packageName: "Weekly In-Person Training",
    includeWorkouts: false,
    workoutFrequency: "weekly",
    includeCheckins: true,
    checkinFrequency: "weekly",
    monthlyPrice: 200,
    tagline: "Weekly studio sessions",
    group: "In-Person Check-Ins",
  },
  {
    name: "In-Person — Bi-Weekly",
    packageName: "Bi-Weekly In-Person Training",
    includeWorkouts: false,
    workoutFrequency: "monthly",
    includeCheckins: true,
    checkinFrequency: "biweekly",
    monthlyPrice: 150,
    tagline: "Every-other-week studio sessions",
    group: "In-Person Check-Ins",
  },
  {
    name: "In-Person — Monthly",
    packageName: "Monthly In-Person Check-In",
    includeWorkouts: false,
    workoutFrequency: "monthly",
    includeCheckins: true,
    checkinFrequency: "monthly",
    monthlyPrice: 125,
    tagline: "Monthly studio check-in",
    group: "In-Person Check-Ins",
  },
  {
    name: "In-Person — Bi-Monthly",
    packageName: "Bi-Monthly Check-In",
    includeWorkouts: false,
    workoutFrequency: "monthly",
    includeCheckins: true,
    checkinFrequency: "bimonthly",
    monthlyPrice: 100,
    tagline: "Check-in every 2 months",
    group: "In-Person Check-Ins",
  },
  // Combined
  {
    name: "Full Service — Weekly",
    packageName: "Full Weekly Coaching",
    includeWorkouts: true,
    workoutFrequency: "weekly",
    includeCheckins: true,
    checkinFrequency: "weekly",
    monthlyPrice: 250,
    tagline: "Weekly programs + weekly sessions",
    group: "Combined",
  },
  {
    name: "Full Service — Bi-Weekly",
    packageName: "Full Bi-Weekly Coaching",
    includeWorkouts: true,
    workoutFrequency: "biweekly",
    includeCheckins: true,
    checkinFrequency: "biweekly",
    monthlyPrice: 200,
    tagline: "Bi-weekly programs + sessions",
    group: "Combined",
  },
  {
    name: "Full Service — Monthly",
    packageName: "Full Monthly Coaching",
    includeWorkouts: true,
    workoutFrequency: "monthly",
    includeCheckins: true,
    checkinFrequency: "monthly",
    monthlyPrice: 175,
    tagline: "Monthly program + studio check-in",
    group: "Combined",
  },
  {
    name: "Full Service — Bi-Monthly",
    packageName: "Full Bi-Monthly Coaching",
    includeWorkouts: true,
    workoutFrequency: "bimonthly",
    includeCheckins: true,
    checkinFrequency: "bimonthly",
    monthlyPrice: 150,
    tagline: "Bi-monthly program + session",
    group: "Combined",
  },
];

export interface WeeklyCheckIn {
  id: string;
  clientId: number;
  weekOf: string;
  trainingQuality: number;
  energyRecovery: number;
  bodyWeight?: number;
  wins: string;
  struggles: string;
  questionsForMatt: string;
  submittedAt: string;
  trainerReply?: string;
  trainerRepliedAt?: string;
  trainerRead?: boolean;
}

export interface Client {
  id: number;
  name: string;
  goal?: string;
  email?: string;
  username: string;
  clientPassword: string;
  entries: Entry[];
  trainerNote: string;
  messages: Message[];
  challengeLogs: ChallengeLog[];
  challengeOptIns: Record<string, boolean>;
  payments: unknown[];
  subscription?: SubscriptionInfo;
}

export interface Challenge {
  id: string;
  name: string;
  description?: string;
  goal: number;
  unit: string;
  active: boolean;
}

export interface SessionType {
  id: string;
  name: string;
  description?: string;
  duration: number;
  price: number;
  type: string;
  active: boolean;
}

export interface AvailSlot {
  id: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
}

export interface Booking {
  id: string;
  clientId: number;
  sessionTypeId: string;
  date: string;
  time: string;
  note?: string;
  status: string;
  bookedAt: string;
}

export interface Assessment {
  id: string;
  clientId: number;
  type: string;
  videoUrl?: string;
  zoomLink?: string;
  zoomDate?: string;
  zoomTime?: string;
  clientNotes?: string;
  trainerNotes?: string;
  worksheetId?: string | null;
  submittedAt: string;
}

export interface ExerciseItem {
  id?: string;
  name: string;
  videoUrl?: string;
  sets?: string;
  reps?: string;
  weight?: string;
  rest?: string;
  coachingCues?: string;
  clientLog?: string;
  clientComment?: string;
}

export interface Worksheet {
  id: string;
  assessmentId?: string;
  clientId?: number;
  title: string;
  notes?: string;
  exercises: ExerciseItem[];
  createdAt?: string;
  updatedAt?: string;
}

export interface HelpRequest {
  id: string;
  name: string;
  email: string;
  category: "workout" | "lift" | "injury" | "badassery";
  details: string;
  videoUrl?: string;
  submittedAt: string;
  trainerReply?: string;
  repliedAt?: string;
  status: "pending" | "replied";
}

export interface CustomProgram {
  id: string;
  clientId: number;
  title: string;
  notes: string;
  exercises: ExerciseItem[];
  status: "requested" | "draft" | "delivered";
  requestedAt: string;
  createdAt?: string;
  deliveredAt?: string;
  clientViewedAt?: string;
}

export interface HomeContent {
  wordsFromMatt: string;
  monthlyFocus: string;
  monthlyFocusTitle: string;
  tightStuffUrl: string;
  quotes: string[];
}

export type GroupClassType =
  | "weekend_rolling"
  | "youth_14_16"
  | "youth_17_18";

export interface GroupClassInterest {
  id: string;
  classType: GroupClassType;
  name: string;
  email: string;
  phone?: string;
  athleteName?: string;
  sport?: string;
  notes?: string;
  submittedAt: string;
}

export type StoreOrderStatus = "pending" | "building" | "sent";
export type TrainingLevel = "beginner" | "intermediate" | "advanced";

export interface StoreOrder {
  id: string;
  name: string;
  email: string;
  phone?: string;
  goals: string;
  level: TrainingLevel;
  equipment?: string;
  notes?: string;
  submittedAt: string;
  status: StoreOrderStatus;
  programTitle?: string;
  sentAt?: string;
}

export interface FormCheckRequest {
  id: string;
  name: string;
  email: string;
  lift: string;
  videoUrl?: string;
  notes: string;
  submittedAt: string;
  status: "pending" | "replied";
  trainerReply?: string;
  repliedAt?: string;
}

export interface CoachingInquiry {
  id: string;
  name: string;
  email: string;
  phone?: string;
  goals: string;
  frequency?: string;
  notes?: string;
  type: "online_coaching" | "meet_prep" | "mentorship";
  submittedAt: string;
  status: "pending" | "contacted";
}

export interface AppData {
  clients: Client[];
  challenges: Challenge[];
  sessionTypes: SessionType[];
  availability: AvailSlot[];
  bookings: Booking[];
  assessments: Assessment[];
  worksheets: Worksheet[];
  helpRequests: HelpRequest[];
  customPrograms: CustomProgram[];
  groupClassInterests: GroupClassInterest[];
  storeOrders: StoreOrder[];
  formCheckRequests: FormCheckRequest[];
  coachingInquiries: CoachingInquiry[];
  weeklyCheckIns: WeeklyCheckIn[];
  nextId: number;
  homeContent: HomeContent;
}

export const DEFAULT_QUOTES = [
  "Your only competition is who you were yesterday.",
  "Pain is temporary. Quitting lasts forever.",
  "The gym doesn't care about your excuses. Neither does Matt.",
  "Strong is a choice you make every single day.",
  "Progress, not perfection.",
];

export const DEFAULT_HOME: HomeContent = {
  wordsFromMatt:
    "Every session counts. Every rep matters. Whether you're here to fix something broken, build something new, or just figure out where to start — you're in the right place. Let's get to work.",
  monthlyFocus:
    "Posterior chain. We're fixing the chain reaction: tight hips, weak glutes, rounded lower back. If you sit all day, this month is specifically for you.",
  monthlyFocusTitle: "March: Posterior Chain",
  tightStuffUrl: "",
  quotes: DEFAULT_QUOTES,
};

export const DEFAULT_SESSION_TYPES: SessionType[] = [
  {
    id: "st_1",
    name: "Single Session",
    description: "One-on-one personal training session, 60 min.",
    duration: 60,
    price: 80,
    type: "single",
    active: true,
  },
  {
    id: "st_3",
    name: "Program Blueprint Session",
    description: "Matt builds a custom program for your goals and location.",
    duration: 90,
    price: 150,
    type: "blueprint",
    active: true,
  },
  {
    id: "st_4",
    name: "Virtual Movement Assessment",
    description:
      "Submit a video or schedule a Zoom. Matt assesses your mechanics.",
    duration: 45,
    price: 100,
    type: "virtual",
    active: true,
  },
  {
    id: "st_5",
    name: "I'm Stuck / Something Hurts / Need a Workout",
    description: "Reach out and Matt will help. Pay what you feel — minimum $1.",
    duration: 30,
    price: 1,
    type: "stuck",
    active: true,
  },
  {
    id: "st_6",
    name: "Team Program Consultation",
    description: "Custom program for any team, any sport, any age. On-site or remote.",
    duration: 60,
    price: 200,
    type: "team",
    active: true,
  },
];

export const EMPTY: AppData = {
  clients: [],
  challenges: [],
  sessionTypes: DEFAULT_SESSION_TYPES,
  availability: [],
  bookings: [],
  assessments: [],
  worksheets: [],
  helpRequests: [],
  customPrograms: [],
  groupClassInterests: [],
  storeOrders: [],
  formCheckRequests: [],
  coachingInquiries: [],
  weeklyCheckIns: [],
  nextId: 1,
  homeContent: DEFAULT_HOME,
};

export const LIFTS = [
  "Squat",
  "Bench Press",
  "Deadlift",
  "Overhead Press",
  "Floor Press",
];

export const DAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export const STATUS_COLORS: Record<string, string> = {
  upcoming: "#4a9eff",
  attended: "#4caf7d",
  cancelled: "#e84040",
  noshow: "#e8621a",
};
export const STATUS_LABELS: Record<string, string> = {
  upcoming: "Upcoming",
  attended: "Attended",
  cancelled: "Cancelled",
  noshow: "No-Show",
};

export const TRAINER_PASSWORD = "coach123";

export function uid(): string {
  return `id_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export function today(): string {
  return new Date().toISOString().split("T")[0];
}

export function nowTs(): string {
  return new Date().toISOString();
}

export function fmt(iso: string): string {
  return new Date(iso + "T12:00:00").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function fmtS(iso: string): string {
  return new Date(iso + "T12:00:00").toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
}

export function getMonday(date: Date = new Date()): string {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  return d.toISOString().split("T")[0];
}

export function fmtTime(t: string): string {
  const [h, m] = t.split(":");
  const hr = +h;
  return `${hr % 12 || 12}:${m} ${hr >= 12 ? "pm" : "am"}`;
}

export async function loadData(): Promise<AppData> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return EMPTY;
    const parsed = JSON.parse(raw) as AppData;
    if (!parsed.homeContent) parsed.homeContent = DEFAULT_HOME;
    if (!parsed.helpRequests) parsed.helpRequests = [];
    if (!parsed.sessionTypes) parsed.sessionTypes = DEFAULT_SESSION_TYPES;
    if (!parsed.customPrograms) parsed.customPrograms = [];
    if (!parsed.groupClassInterests) parsed.groupClassInterests = [];
    if (!parsed.storeOrders) parsed.storeOrders = [];
    if (!parsed.formCheckRequests) parsed.formCheckRequests = [];
    if (!parsed.coachingInquiries) parsed.coachingInquiries = [];
    if (!parsed.weeklyCheckIns) parsed.weeklyCheckIns = [];
    return parsed;
  } catch {
    return EMPTY;
  }
}

export async function persistData(d: AppData): Promise<void> {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(d));
  } catch {}
}

export function getAvailableSlots(
  availability: AvailSlot[],
  bookings: Booking[],
  days = 21
): { date: string; time: string; slotId: string }[] {
  const slots: { date: string; time: string; slotId: string }[] = [];
  const now = new Date();
  for (let i = 1; i <= days; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() + i);
    const dow = d.getDay();
    const ds = d.toISOString().split("T")[0];
    (availability || [])
      .filter((a) => a.dayOfWeek === dow)
      .forEach((s) => {
        const taken = (bookings || []).some(
          (b) =>
            b.date === ds &&
            b.time === s.startTime &&
            b.status !== "cancelled"
        );
        if (!taken) slots.push({ date: ds, time: s.startTime, slotId: s.id });
      });
  }
  return slots.sort(
    (a, b) =>
      a.date.localeCompare(b.date) || a.time.localeCompare(b.time)
  );
}
